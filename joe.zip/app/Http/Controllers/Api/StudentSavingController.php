<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\Staff; // <-- Tambahkan
use Illuminate\Http\Request;

class StudentSavingController extends Controller
{
    // Fungsi helper untuk memeriksa otorisasi guru
    private function authorizeTeacher(Student $student)
    {
        $user = auth()->user();
        if ($user->role === 'guru') {
            $staff = Staff::where('user_id', $user->id)->first();
            if (!$staff || !$staff->classGroups()->whereHas('students', fn($q) => $q->where('id', $student->id))->exists()) {
                abort(403, 'Akses ditolak.');
            }
        }
    }

    public function index(Student $student)
    {
        $this->authorizeTeacher($student); // Cek otorisasi

        $transactions = $student->savings()->latest('transaction_date')->get();
        $balance = $transactions->where('type', 'Setoran')->sum('amount') - $transactions->where('type', 'Penarikan')->sum('amount');

        return response()->json([
            'balance' => $balance,
            'transactions' => $transactions,
        ]);
    }

    public function store(Request $request, Student $student)
    {
        $this->authorizeTeacher($student); // Cek otorisasi

        $data = $request->validate([
            'type' => 'required|in:Setoran,Penarikan',
            'amount' => 'required|numeric|gt:0',
            'description' => 'nullable|string|max:255',
        ]);

        if ($data['type'] === 'Penarikan') {
            $transactions = $student->savings()->get();
            $balance = $transactions->where('type', 'Setoran')->sum('amount') - $transactions->where('type', 'Penarikan')->sum('amount');
            if ($data['amount'] > $balance) {
                return response()->json(['message' => 'Saldo tidak mencukupi.'], 422);
            }
        }

        $transaction = $student->savings()->create([
    'transaction_date' => now(),
    'type' => $data['type'],
    'amount' => $data['amount'],
    'description' => $data['description'],
    'user_id' => auth()->id(), // <-- Tambahkan baris ini
]);

        return response()->json($transaction, 201);
    }
}
