<?php

namespace App\Console\Commands;

use App\Models\CostItem;
use App\Models\Student;
use App\Models\StudentBill;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class BillMonthlySpp extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    // PERUBAHAN 1: Tambahkan argumen opsional --month dan --year
    protected $signature = 'spp:bill {--month=} {--year=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Membuat tagihan SPP bulanan untuk semua siswa aktif';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Memulai proses penagihan SPP...');

        // PERUBAHAN 2: Tentukan tanggal berdasarkan input atau tanggal saat ini
        $month = $this->option('month');
        $year = $this->option('year');

        // Jika ada input bulan dan tahun, gunakan itu. Jika tidak, gunakan waktu sekarang.
        $dateToBill = ($month && $year) ? Carbon::create($year, $month, 1) : Carbon::now();

        $this->info("Membuat tagihan untuk: " . $dateToBill->translatedFormat('F Y'));

        // 1. Cari template SPP
        $sppTemplate = CostItem::where('cost_code', 'SPP_TEMPLATE')->first();
        if (!$sppTemplate) {
            $this->error('Gagal! Item biaya dengan cost_code "SPP_TEMPLATE" tidak ditemukan.');
            return 1;
        }

        // 2. Buat item biaya baru untuk bulan target berdasarkan template
        $monthName = $dateToBill->translatedFormat('F Y');
        $sppThisMonthName = "SPP {$monthName}";

        $sppThisMonth = CostItem::firstOrCreate(
            ['name' => $sppThisMonthName],
            [
                'type' => 'Tetap',
                'amount' => $sppTemplate->amount,
                'is_active' => true
            ]
        );
        $this->info("Item biaya '{$sppThisMonthName}' sudah siap.");

        // 3. Ambil semua siswa aktif
        $activeStudents = Student::where('status', 'Aktif')->get();
        if ($activeStudents->isEmpty()) {
            $this->warn('Tidak ada siswa aktif yang ditemukan. Proses selesai.');
            return 0;
        }

        // 4. Buat tagihan untuk setiap siswa
        $billedCount = 0;
        foreach ($activeStudents as $student) {
            $existingBill = StudentBill::where('student_id', $student->id)
                                        ->where('cost_item_id', $sppThisMonth->id)
                                        ->exists();

            if (!$existingBill) {
                StudentBill::create([
                    'student_id' => $student->id,
                    'cost_item_id' => $sppThisMonth->id,
                    'remaining_amount' => $sppThisMonth->amount,
                    'status' => 'Belum Lunas',
                    'due_date' => null,
                ]);
                $billedCount++;
            }
        }

        $this->info("Penagihan selesai. {$billedCount} tagihan SPP baru telah dibuat.");
        return 0;
    }
}
