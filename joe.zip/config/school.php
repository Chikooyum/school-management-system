<?php

return [
    'name' => env('SCHOOL_NAME', 'TK Harapan Bangsa'),
    'address' => env('SCHOOL_ADDRESS', 'Jalan Pendidikan No. 123, Batam'),
];
