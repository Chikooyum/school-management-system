<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kwitansi Pembayaran</title>
    <style>
        body { font-family: sans-serif; margin: 40px; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; }
        .header p { margin: 0; }
        .content { margin-top: 30px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        .total { font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
    <table style="width: 100%; border: none;">
        <tr>
            <td style="width: 20%;">
                
                <img src="<?php echo e(public_path('images/logo.png')); ?>" alt="Logo Sekolah" style="width: 80px; height: auto;">
            </td>
            <td style="width: 80%; text-align: right; vertical-align: middle;">
                <h1><?php echo e(config('school.name')); ?></h1>
                <p><?php echo e(config('school.address')); ?></p>
            </td>
        </tr>
    </table>
    <hr>
    <h2>KWITANSI PEMBAYARAN</h2>
</div>

    <div class="content">
        <p><strong>No. Kwitansi:</strong> <?php echo e($payment->receipt_number); ?></p>
        <p><strong>Telah diterima dari:</strong> <?php echo e($payment->studentBill->student->name); ?></p>
        <p><strong>Tanggal Bayar:</strong> <?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('d F Y')); ?></p>
        <p><strong>Diproses oleh:</strong> <?php echo e($payment->user->name); ?></p>

        <br>

        <table>
            <thead>
                <tr>
                    <th>Keterangan</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Pembayaran untuk <?php echo e($payment->studentBill->costItem->name); ?></td>
                    <td>Rp <?php echo e(number_format($payment->amount_paid, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td class="total">Total Bayar</td>
                    <td class="total">Rp <?php echo e(number_format($payment->amount_paid, 0, ',', '.')); ?></td>
                </tr>
            </tfoot>
        </table>

        <br>
        <p><strong>Sisa Tagihan:</strong> Rp <?php echo e(number_format($payment->studentBill->remaining_amount, 0, ',', '.')); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\school-management-system\resources\views/receipts/default.blade.php ENDPATH**/ ?>